# 목차

Starcraft : Broodwar 게임을 플레이하는 인공지능 봇을 개발하는 방법에 대해 설명합니다.

## 도입

* [스타크래프트 게임을 잘 몰라도 되나요?](./Intro1)

## 대회 규칙

* [2017 알고리즘 경진대회 규칙](./Rule1)

## 개발환경 설정

* [스타크래프트 게임 설치 및 패치 적용](./Environment1)

* [BWAPI 라이브러리 및 추가 파일 설치](./Environment2)

* 개발 IDE 설정 및 봇 프로그램 실행해보기 ([C++](./Environment3) / [JAVA](./Environment4))

* [팀 협업환경 설정](./Environment5)

## BWAPI 및 BWTA 라이브러리 소개

* [BWAPI 라이브러리](./Bwapi1)

* [BWTA 라이브러리](./Bwta1)

## 봇 개발 튜터리얼

* 간단하게 작성된 봇 프로그램을 통해 봇이 어떤 식으로 작동하는지, 어떤 식으로 개발하는지 살펴보겠습니다.

* (입문 단계) 봇 프로그램 기본 구조 살펴보기 ([C++](./TutorialLevel0Bot_C) / [JAVA](./TutorialLevel0Bot_JAVA))

* (초급 단계) BWAPI 사용해보기 ([C++](./TutorialLevel1Bot_C) / [JAVA](./TutorialLevel1Bot_JAVA))

* (초급 단계) 적군 정보 업데이트하기 ([C++](./TutorialLevel20Bot_C) / [JAVA](./TutorialLevel2Bot_JAVA))

* (초급 단계) 일꾼으로 자원 채취하기 ([C++](./TutorialLevel3Bot_C) / [JAVA](./TutorialLevel3Bot_JAVA))

* (초급 단계) 건물 건설 및 유닛 훈련하기 ([C++](./TutorialLevel4Bot_C) / [JAVA](./TutorialLevel4Bot_JAVA))

## BasicBot 을 활용한 봇 개발 방법

* 알고리즘 경진대회는 BasicBot 을 수정하여 제출하는 식으로 진행됩니다. BasicBot 은 봇 프로그램 개발에 있어서 기본적이고 모두에게 공통적인 부분들을 미리 개발해놓은 것입니다.

* BasicBot 의 구조 살펴보기 ([C++](./BasicBot1_C) / [JAVA](./BasicBot1_JAVA))

* BasicBot 을 활용한 FastRushBot 개발 예시 ([C++](./BasicBot2_C) / [JAVA](./BasicBot2_JAVA))

## 참고

* [스타크래프트 인공지능 국제 대회 소개](./Etc1)

* 스타크래프트 기존 봇 소개

* 스타크래프트 기존 봇 실행시키는 방법

* 스타크래프트 기존 봇과 겨뤄보는 방법

* 스타크래프트 치트키

* 스타크래프트 게임에 대한 링크들 모음


