# JAVA 개발환경 설정 및 봇 프로그램 실행해보기

## SDK 및 IDE 설치하기

1. 2017 알고리즘 경진대회 웹사이트에서 JDK 설치파일을 다운받아 실행합니다

1. Eclipse 혹은 intelliJ 설치파일을 다운받아 설치합니다. 편의상 Eclipse 를 기준으로 설명하겠습니다.

## BasicBot 설치하기

1. 2017 알고리즘 경진대회 웹사이트에서 BasicBot.zip 을 다운받아 개발폴더 (ex: C:\Algorithm2017\BasicBot) 에 압축을 해제합니다

## 스타크래프트 게임과 봇 프로그램 실행시키기

1. 봇 프로그램을 실행하기 전에 먼저 chaoslauncher 를 사용하여 스타크래프트를 실행시켜야 합니다. chaoslauncher 를 실행시킨 후 Start 버튼을 클릭하여 스타크래프트를 실행시킵니다

1. Eclipse 를 실행시킵니다

1. 메뉴 -> File -> Import... 를 선택합니다

1. General -> Existing Projects into Workspace 를 선택합니다

1. Select root directory 오른쪽의 Browse 버튼을 눌러 개발폴더\JAVA 를 선택합니다

1. Projects 목록 오른쪽의 Select All 버튼을 눌러 모든 프로젝트를 Import 합니다

1. Package Explorer -> TutorialLevel0Bot 우클릭 -> Run As -> Java Application 을 실행합니다. Console 탭에서 봇 프로그램이 실행될 것입니다

1. 스타크래프트 -> Single Player 클릭 (단축키 S) -> Expansion 클릭 (단축키 E) - New ID 생성 및 OK 클릭 -> Play Custom 클릭 (단축키 U) -> 게임 맵 선택 (ex: NeoLostTemple2.0.scm) -> Game Type 선택 (ex: Free For All) -> 플레이어로 Computer 가 1개만 남도록 변경 -> OK 클릭 -> 대결이 시작됩니다

1. 명령 프롬프트 화면 및 게임 화면을 살펴보세요. 봇 프로그램의 구조에 대해서는 Level0Bot 구조 살펴보기 페이지에서 설명하겠습니다.

## 봇 프로그램 디버깅 방법

1. 명령 프롬프트 화면을 클릭한 후 Pause (Break) 키를 누르면, 명령 프롬프트 화면 출력이 일어날 때 게임도 정지하게 됩니다

