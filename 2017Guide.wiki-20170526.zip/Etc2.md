# 사람 vs 봇 프로그램 대결 실행시키는 방법



1. Chaoslauncher - MultiInstance.exe 를 실행시킵니다

1. Chaoslauncher 화면에서 BWAPI 4.1.2 Injector [RELEASE] 체크박스에 체크 한 후, Start 버튼을 눌러 StarCraft 인스턴스를 실행시킵니다

    * 첫번째 인스턴스는 봇 프로그램이 게임조작을 하는 인스턴스가 됩니다

    * 메모장 등으로 C:\StarCraft\bwapi-data\bwapi.ini 를 편집 후 저장합니다. 단, bwapi.ini 는 반드시 ANSI 인코딩으로 저장해야 합니다

        * EXE 나 JAR 형태의 봇 프로그램인 경우

        * DLL 형태의 봇 프로그램인 경우


    * Multi Player 클릭 -> Expansion 클릭 -> Local PC 클릭 -> ID 입력 (ex: Bot) -> Create Game 클릭 -> MapSamsungSDS 폴더에 있는 맵 선택 -> OK 클릭


1. Chaoslauncher 화면에서 BWAPI 4.1.2 Injector [RELEASE] 체크박스에 체크 해제 한 후, Start 버튼을 눌러 StarCraft 인스턴스를 실행시킵니다

    * 두번째 인스턴스는 사람이 게임조작을 하는 인스턴스가 됩니다

    * Multi Player 클릭 -> Expansion 클릭 -> Local PC 클릭 -> ID 입력 (ex: Human) -> 생성되어있는 경기 클릭



