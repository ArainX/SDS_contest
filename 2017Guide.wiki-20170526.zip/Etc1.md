# 스타크래프트 인공지능 국제 대회 소개

스타크래프트 인공지능 국제 대회가 매년 공식적으로 개최되고 있으며, 전세계적으로 약 70개의 스타크래프트 인공지능 봇이 참여하여 랭킹을 다투고 있습니다.

* [AIIDE (Artificial Intelligence and Interactive Digital Entertainment)](http://www.cs.mun.ca/~dchurchill/starcraftaicomp/history.shtml)

* [IEEE CIG (IEEE Conference on Computational Intelligence and Games)](https://cilab.sejong.ac.kr/sc_competition/)

* [SSCAIT (Student StarCraft AI Tournament)](http://sscaitournament.com/)


>[관련 기사 링크 : 스타크래프트 AI, 인공지능 학회서 바둑 이상 치열한 경쟁](http://news.inews24.com/php/news_view.php?g_menu=020200&g_serial=947395)