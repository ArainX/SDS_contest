# Documentation using Doxygen

## Doxygen 소개

* Doxygen 은 소스코드로부터 Documentation 파일들을 만들어내는 오픈소스 프로그램 입니다.

* C, C++, JAVA, Python 등 여러 언어의 소스코드에 대해 사용 가능합니다

* HTML, DOC, XML, Man page 등 다양한 출력이 가능합니다

* 다운로드 및 메뉴얼 : [https://www.doxygen.org](https://www.doxygen.org)


## Doxygen 사용법 간단 소개

* 설치 후 Doxywizard 를 실행해서, Step 1, Step 2 .. 를 따라해보세요

* 한글 인코딩 깨짐 문제 해결 방법 : [http://codemuri.tistory.com/431](http://codemuri.tistory.com/431)

* JAVA Doc Style 과 유사하도록 소스코드에 다음과 같이 Documentation 을 작성합니다

  * 일반적으로 다음 방법을 사용합니다

```c
  /// 설명
  /// @param arg 파라메터 설명
  /// @return 리턴값 설명
  /// @see 추가설명 링크
  void someFunction(int arg);
```

  * enum 의 경우에는 다음 방법으로 작성합니다

```c
  enum Enum {
      a, ///< 설명
      b, ///< 설명
      c  ///< 설명
  };
```

  
