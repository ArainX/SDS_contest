# BWAPI 라이브러리

BWAPI 라이브러리의 주요 구성 요소에 대해 설명합니다

## BWAPI 라이브러리 개요

* BWAPI (Brood War Application Programming Interface) 는 스타크래프트 (Starcraft: Broodwar) 게임과 상호작용하는 무료 오픈소스 라이브러리 입니다.

* Adam Heinermann 이라는 미국 프로그래머를 비롯한 몇몇 개발자들이 개인적으로 만든 라이브러리이며, 스타크래프트의 EULA (END USER LICENSE AGREEMENT) 에는 위배되지만 스타크래프트 개발회사 Blizzard 가 연구목적으로의 사용을 허가하였습니다.

* 봇 프로그램은 BWAPI 의 클래스 및 변수들을 통해 스타크래프트 게임의 실행 상황을 파악하고 게임 플레이를 할 수 있습니다

## BWAPI 라이브러리 버전 선택

* 2017 알고리즘 경진대회에서는 BWAPI 4.1.2 버전을 사용합니다. 하위 버전 / 상위 버전과 호환성이 없기 때문에, 반드시 BWAPI 4.1.2 버전을 설치하셔서 사용해야 합니다.

* SSCAIT 등 웹사이트에 봇 프로그램(EXE/DLL/JAR) 및 봇 오픈소스들이 있는데, 봇 프로그램이 사용하는 BWAPI 버전을 확인하셔서 정확하게 일치하는 BWAPI 를 설치해야 작동합니다.

* BWAPI 버전별 차이는 다음과 같습니다

|BWAPI 버전|bwapi.dll 파일 사이즈|특징|
|----|----|----|
|4.1.2|593KB|1 PC에서 여러 Instance 실행가능|
|3.7.5|592KB|1 PC에서 여러 Instance 실행불가능|
|3.7.4|619KB|1 PC에서 여러 Instance 실행불가능|

## BWAPI 구성

* BWAPI 라이브러리를 설치하면 여러 구성요소들이 설치되는데, 그 중 중요한 몇가지만 소개합니다

|폴더 경로|설명|
|----|----|
|C:\BWAPI412\Chaoslauncher|스타크래프트 게임을 실행시키면서 bwapi.dll 및 봇 프로그램을 연계시키는 Chaoslauncher 프로그램입니다. **Chaoslauncher - MultiInstance.exe를 실행시키면 됩니다**|
|C:\StarCraft\bwapi-data|bwapi.dll 및 bwapi.dll 의 실행 설정파일인  bwapi.ini 파일이 위치하는 폴더입니다. 일반적으로 이 폴더 하위에 봇 프로그램을 위치시키고 실행시킵니다. **bwapi.ini 는 ANSI Encoding 방식으로 저장해야 합니다**|
|C:\StarCraft\bwlibrary\BWAPI412\include|C++로 봇 프로그램 개발 시 include 시키는 헤더파일들 입니다|
|C:\StarCraft\bwlibrary\BWAPI412\lib|C++로 봇 프로그램 개발 시 link 시키는 라이브러리 파일들 입니다|
|C:\StarCraft\bwlibrary\BWAPI412\documentation|BWAPI Documentation 웹사이트 입니다. index.html 을 실행시키면 됩니다|


## BWAPI 주요 클래스 및 함수

* 봇 프로그램을 개발하는데 있어서 가장 많이 쓰이는 BWAPI 클래스/함수/객체들을 소개합니다

|타입|명칭(C++)|명칭(JAVA)|설명|
|----|----|----|--------------------|
|Game|BWAPI::Broodwar|game|게임의 모든 객체들 및 상태들을 포함하는 객체|
|Player|BWAPI::Broodwar->self()|game.self()|아군 플레이어 객체를 반환하는 함수|
|Player|BWAPI::Broodwar->enemy()|game.enemy()|적군 플레이어 객체를 반환하는 함수|
|RaceType|BWAPI::Broodwar::RaceTypes|bwapi.Race|스타크래프트 종족 타입에 대한  클래스|
|Race|BWAPI::Broodwar->self()->getRace()|game.self().getRace()|아군 플레이어의 종족 정보 객체를 반환하는 함수|
|Race|BWAPI::RaceTypes::Protoss|bwapi.Race.Protoss|스타크래프트 종족 목록 중 Protoss 종족을 의미하는 객체|
|Race|BWAPI::RaceTypes::Terran|bwapi.Race.Terran|스타크래프트 종족 목록 중 Terran 종족을 의미하는 객체|
|Race|BWAPI::RaceTypes::Zerg|bwapi.Race.Zerg|스타크래프트 종족 목록 중 Zerg 종족을 의미하는 객체|
|Position|BWAPI::Position|bwapi.Position|게임 맵 상에서의 위치좌표. 1 Pixel x 1 Pixel 단위. 1 Tile = 32 Pixel 이므로, 128 Tile x 128 Tile 사이즈의 게임 맵일 경우, 게임 맵 좌상단의 좌표는 (0,0), 게임 맵 우하단의 좌표는 (128*32-1, 128*32-1) 이 됨|
|TilePosition|BWAPI::TilePosition|bwapi.TilePosition|게임 맵 상에서의 위치좌표. 1 Tile x 1 Tile 단위. 128 Tile x 128 Tile 사이즈의 게임 맵일 경우, 게임 맵 좌상단의 좌표는 (0,0), 게임 맵 우하단의 좌표는 (127, 127) 이 됨|
|TilePosition|BWAPI::Broodwar->self()->getStartLocation()|game.self().getStartLocation()|아군 플레이어의 시작 위치 (첫 건물 위치)를 반환하는 함수|
|Region|BWAPI::Region|bwapi.Region|게임 맵 상에서 Properties 값이 같은 타일들의 집합을 의미하는 단위에 대한 클래스. 길찾기 알고리즘이나 길목찾기 알고리즘 구현에 유용하게 사용될 수 있음|
|UnitType|BWAPI::UnitTypes|bwapi.UnitType|스타크래프트 유닛 타입에 대한 클래스|
|UnitType|BWAPI::UnitTypes::Terran_Marine|bwapi.UnitType.Terran_Marine|스타크래프트의 테란 종족의 Marine 유닛 타입을 의미하는 객체|
|UnitType|BWAPI::UnitTypes::Terran_Command_Center|bwapi.UnitType.Terran_Command_Center|스타크래프트의 테란 종족의 Command_Center 유닛 타입을 의미하는 객체|
|Unit|BWAPI::Unit|bwapi.Unit|스타크래프트의 유닛을 의미하는 객체. 유닛에는 건물, 지상유닛, 공중유닛이 포함됨|
|UnitSet/List|BWAPI::Broodwar->self()->getUnits()|game.self().getUnits()|아군 플레이어에 속한 모든 유닛을 반환하는 함수|
|int|unit->getHitPoints()|unit.getHitPoints()|유닛의 HitPoint (0가 되면 사망)을 반환하는 함수|
|void|unit->move()|unit.move()|유닛에게 이동을 지시하는 함수|
|bool|unit->isMoving()|unit.isMoving()|유닛이 이동 중인지 여부를 반환하는 함수|
|BulletType|BWAPI::BulletType|bwapi.BulletType|스타크래프트의 유닛이 발사하는 미사일 따위의 불렛 타입에 대한 클래스. BulletType에는 Zerg_Lurker 유닛이 발사하는 Subterranean_Spines 라든가, Terran_Valkyrie 유닛이 발사하는 Halo_Rockets 등이 있음|
|TechType|BWAPI::TechTypes|bwapi.TechType|스타크래프트 게임에서 유닛이 사용하는 기술 타입에 대한 클래스. TechType에는 Protoss_High_Templar 유닛이 사용하는 Psionic_Storm 라든가, Terran_Comsat_Station 유닛이 사용하는 Scanner_Sweep 등이 있음|
|UpgradeType|BWAPI::UpgradeTypes|bwapi.UpgradeType|스타크래프트 게임에서 기존 성능을 강화하는 업그레이드 타입에 대한 클래스. UpgradeType에는 Protoss_High_Templar 유닛의 최대 에너지 한계값을 증가시키는 Khaydarin_Amulet 라든가, Terran 종족 지상 메카닉 유닛들의 공격력을 증가시키는 Terran_Ship_Weapons 등이 있음|

* BWAPI 에 대한 상세한 내용은 BWAPI Documentation 웹사이트를 참고하세요 : [http://bwapi.github.io](http://bwapi.github.io)

* BWAPI 라이브러리를 설치하는 것과 별도로, [https://github.com/bwapi/bwapi](https://github.com/bwapi/bwapi) 에서 master branch 를 clone 혹은 다운받아 소스코드를 보시면 훨씬 더 자세하게 내부구조를 파악할 수 있습니다 (Visual Studio 로 bwapi\bwapi.sln 파일을 열면 됩니다)
