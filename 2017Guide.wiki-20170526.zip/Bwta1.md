# BWTA 라이브러리

BWTA 라이브러리의 주요 구성 요소에 대해 설명합니다

## BWTA 라이브러리 개요

* BWTA (Brood War Terrain Analyzer) 는 BWAPI 를 사용하여 게임 맵을 분석하고 분석 결과를 반환하는 함수들을 포함하는 add-on 라이브러리 입니다.

* 봇 프로그램은 BWTA 의 함수들을 사용하여 게임 맵을 쉽게 파악하고 활용할 수 있습니다

## BWTA 라이브러리 버전 선택

* 2017 알고리즘 경진대회에서는 BWTA 2.2 버전을 사용합니다. BWAPI 버전과 호환성을 맞춰야 하기 때문에, 반드시 BWTA 2.2 버전을 설치하셔서 사용해야 합니다.

* BWTA 는 일반적이지 않은 맵 (자원 무한 맵 등) 에서는 Crash 를 일으키거나 비정상적으로 작동합니다.

## BWTA 구성

* BWTA 라이브러리에는 다음 구성요소들이 있습니다

|폴더 경로|설명|
|----|----|
|C:\StarCraft\bwlibrary\BWTA22\include|C++로 봇 프로그램 개발 시 include 시키는 헤더파일들 입니다|
|C:\StarCraft\bwlibrary\BWTA22\lib|C++로 봇 프로그램 개발 시 link 시키는 라이브러리 파일들 입니다|
|C:\StarCraft\bwlibrary\BWTA22\windows|몇몇 dll 파일들이 있는데 윈도우 폴더에 복사해야 합니다|

## BWTA 주요 클래스 및 함수

* 봇 프로그램을 개발하는데 있어서 가장 많이 쓰이는 BWTA 클래스/함수/객체들을 소개합니다

|타입|명칭(C++)|명칭(JAVA)|설명|
|----|----|----|--------------------|
|BaseLocation|BWTA::BaseLocation|bwta.BaseLocation|게임 맵에서 진지를 건설하기에 적합한 장소를 의미하는 클래스. 주위에 Mineral Field, Gas Geyser 등이 있음|
|set/List|BWTA::getBaseLocations()|bwta.BWTA.getBaseLocations()|게임 맵에서 모든 BaseLocation 들을 반환하는 함수|
|set/List|BWTA::getStartLocations()|bwta.BWTA.getStartLocations()|게임 맵에서 BaseLocation 중 게임 시작 시 플레이어의 초기 진지 위치로 결정될 수 있는 BaseLocation 들을 반환하는 함수|
|Polygon|BWTA::Polygon|bwta.Polygon|여러개의 BWAPI::Position들로 이루어진 다각형을 의미하는 클래스|
|Region|BWTA::Region|bwta.Region|게임 맵에서 Polygon 을 바운더리 외곽 경계선으로 하는 타일들의 집합을 의미하는 클래스. 지역에 해당함|
|Chokepoint|BWTA::Chokepoint|bwta.Chokepoint|게임 맵에서 Region 과 Region 사이의 경계선을 의미하는 클래스. 길목에 해당함|
|Chokepoint|BWTA::getNearestChokepoint(int x, int y)|bwta.BWTA.getNearestChokepoint(int x, int y)|게임 맵에서 (x,y) 좌표에서 가장 가까운 길목을 반환하는 함수|

* BWTA 에 대한 상세한 내용은 BWTA Documentation 웹사이트를 참고하세요 : [https://bitbucket.org/auriarte/bwta2/wiki/Home](https://bitbucket.org/auriarte/bwta2/wiki/Home)

* BWTA 라이브러리를 설치하는 것과 별도로, [https://bitbucket.org/auriarte/bwta2/src](https://bitbucket.org/auriarte/bwta2/src) 에서 master branch 를 clone 혹은 다운받아 소스코드를 보시면 훨씬 더 자세하게 내부구조를 파악할 수 있습니다 (Visual Studio 로 bwta2.sln 파일을 열면 됩니다)
