# BasicBot 을 활용한 Protoss_DarkTemplarRushBot 개발 예시

* 2017 알고리즘 경진대회는 BasicBot 프로젝트를 수정하여 봇 프로그램을 개발하는 것입니다.

* 짧은 시간내에 효과적으로 봇 프로그램을 개발하기 위해서는, 먼저 개발 방향과 개발 범위를 잘 수립한 후, BasicBot 에 대해 최소한만 추가/수정하여 개발하는 것을 권장합니다.

* 예시로써, BasicBot 의 StrategyManager 만 수정해서 Protoss_DarkTemplarRushBot 을 개발해보겠습니다.

## 개발 환경 설정

1. Visual Studio Express 2013 를 실행시킵니다

1. 메뉴 -> File -> Open Project -> 개발폴더\C\BasicBot.sln 을 선택합니다

1. Solution Explorer -> TutorialLevel5Bot 우클릭 -> Set as StartUp Project 를 실행합니다

## 개발 방향

1. 아군 종족 결정 : Protoss

1. 게임 전략 : 초반에는 Protoss 종족의 기본 지상 유닛인 Zealot 으로 최소한의 방어를 하고, 빠르게 Tech Tree 를 높여 고급 지상 유닛 Dark Templar 2개를 생산한 후 Dark Templar 유닛을 선두로 하여 총공격을 가한다

## 개발 범위

1. 봇 이름 변경

1. 빌드 오더 입력

1. 공격 시작 조건 변경

## 1. 봇 이름 변경

* 프로젝트 이름을 Protoss_DarkTemplarRushBot 으로 설정합니다.

* 프로젝트 이름으로 exe  파일이 만들어지기 때문입니다.

## 2. 빌드 오더 입력

* StrategyManager 의 setInitialBuildOrder() 에서 다음의 빌드 오더를 빌드 큐에 초기값으로 입력하도록 수정하였습니다.

```c
(StrategyManager.cpp)

void StrategyManager::setInitialBuildOrder()
{
	if (BWAPI::Broodwar->self()->getRace() == BWAPI::Races::Protoss) {
		
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());

		// SupplyUsed가 7 일때 파일런 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getBasicSupplyProviderUnitType(), BuildOrderItem::SeedPositionStrategy::MainBaseLocation);

		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());

		// SupplyUsed가 8 일때 1번째 게이트웨이 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Gateway, BuildOrderItem::SeedPositionStrategy::MainBaseLocation);
		
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());

		// SupplyUsed가 9 일때 가스 리파이너리 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getRefineryBuildingType());

		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());

		// SupplyUsed가 10 일때 사이버네틱스 코어 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Cybernetics_Core, BuildOrderItem::SeedPositionStrategy::MainBaseLocation);

		// 1번째 질럿 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Zealot);

		// SupplyUsed가 12 일때 시타델 오브 아둔 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Citadel_of_Adun);

		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());

		// SupplyUsed가 14 일때 템플러 아카이브, 2번째 게이트웨이 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Templar_Archives);
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Gateway, BuildOrderItem::SeedPositionStrategy::MainBaseLocation);

		// 2번째 질럿 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Zealot);

		// SupplyUsed가 16 일때 파일런 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getBasicSupplyProviderUnitType(), BuildOrderItem::SeedPositionStrategy::MainBaseLocation);

		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getWorkerType());

		// 4마리 다크 템플러 빌드 후 파일런 빌드
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Dark_Templar);
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Dark_Templar);
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Dark_Templar);
		BuildManager::Instance().buildQueue.queueAsLowestPriority(BWAPI::UnitTypes::Protoss_Dark_Templar);
		BuildManager::Instance().buildQueue.queueAsLowestPriority(InformationManager::Instance().getBasicSupplyProviderUnitType(), BuildOrderItem::SeedPositionStrategy::MainBaseLocation);
    }
}
```

## 3. 공격 시작 조건 변경

* Dark Templar 유닛 2개가 생산 완료되면 공격 모드로 전환하도록 수정하였습니다.

```c
(StrategyManager.cpp)

void StrategyManager::executeCombat()
{
	// 공격 모드가 아닐 때에는 전투유닛들을 아군 진영 길목에 집결시켜서 방어
	if (isFullScaleAttackStarted == false)		
	{
		BWTA::Chokepoint* firstChokePoint = BWTA::getNearestChokepoint(InformationManager::Instance().getMainBaseLocation(InformationManager::Instance().selfPlayer)->getTilePosition());

		for (auto & unit : BWAPI::Broodwar->self()->getUnits())
		{
			if (unit->getType() == InformationManager::Instance().getBasicCombatUnitType() && unit->isIdle()) {
				CommandUtil::attackMove(unit, firstChokePoint->getCenter());
			}
		}

		// Protoss_Dark_Templar 유닛이 2개 이상 생산되었고, 적군 위치가 파악되었으면 총공격 모드로 전환
		if (BWAPI::Broodwar->self()->completedUnitCount(BWAPI::UnitTypes::Protoss_Dark_Templar) >= 2) {

			if (InformationManager::Instance().enemyPlayer != nullptr
				&& InformationManager::Instance().enemyRace != BWAPI::Races::Unknown
				&& InformationManager::Instance().getOccupiedBaseLocations(InformationManager::Instance().enemyPlayer).size() > 0)
			{				
				isFullScaleAttackStarted = true;
			}
		}

	}
	// 공격 모드가 되면, 모든 전투유닛들을 적군 Main BaseLocation 로 공격 가도록 합니다
	else {
		...
	}
	...
}
```


* 빌드 및 실행을 해봅시다. 빌드오더가 순차적으로 실행되어, Dark Templar Rush 공격을 하는 것을 볼 수 있습니다.

* Protoss 종족의 Dark Templar Rush 전략은 적군 종족이 Terran 이거나 Protoss 일때는 승리할 확률이 높지만, Zerg 종족을 상대로는 거의 승리하지 못하는 전략입니다. 적군 종족에 따라 다른 전략을 사용하는 등 자신만의 전략을 개발해보세요.