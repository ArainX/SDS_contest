# BasicBot 의 구조 살펴보기

알고리즘 경진대회 제출용 봇 프로그램인 BasicBot 의 기본적인 구조를 살펴보겠습니다.

## 개발 환경 설정

1. Visual Studio Express 2013 를 실행시킵니다

1. 메뉴 -> File -> Open Project -> 개발폴더\C\BasicBot.sln 을 선택합니다

1. Solution Explorer -> BasicBot 우클릭 -> Set as StartUp Project 를 실행합니다


## 파일 목록

BasicBot 프로젝트를 구성하는 주요 파일들은 다음과 같습니다.

※ Common.h 를 제외한 다른 헤더파일들은 생략

|파일명|설명|
|----|----|
|main.cpp|봇 프로그램의 시작 지점입니다. 스타크래프트 게임과 Connection 을 맺고, MyBotModule을 실행시키고, 스타크래프트 게임이 종료되면 봇 프로그램을 종료시킵니다|
|Common.h|각종 라이브러리 및 유틸리티를 include 시키는 헤더파일|
|MyBotModule.cpp|스타크래프트 게임에서 발생하는 각 이벤트를 GameCommander 가 처리하도록 전달합니다|
|GameCommander.cpp|각각의 스타크래프트 게임 이벤트가 적절하게 처리되도록 해당 객체에게 이벤트를 전달합니다|
|InformationManager.cpp|게임 상황정보 중 일부를 자체 자료구조 및 변수들에 저장하고 업데이트합니다|
|StrategyManager.cpp|상황을 판단하여, 정찰, 빌드, 공격, 방어 등을 수행하도록 총괄 지휘를 합니다|
|WorkerManager.cpp|일꾼 유닛들의 상태를 관리하고 컨트롤합니다|
|ScoutManager.cpp|정찰 유닛들의 상태를 관리하고 컨트롤 합니다|
|BuildManager.cpp|빌드(건물 건설 / 유닛 훈련 / 테크 리서치 / 업그레이드) 명령을 순차적으로 실행하기 위해 빌드 큐를 관리하고, 빌드 큐에 있는 명령을 하나씩 실행합니다. 빌드 명령 중 건물 건설 명령은 ConstructionManager로 전달합니다|
|ConstructionManager.cpp|건물 건설 명령 목록을 리스트로 관리하고, 건물 건설 명령이 잘 수행되도록 컨트롤합니다|
|UXManager.cpp|봇 프로그램 개발의 편의성 향상을 위해 게임 화면에 추가 정보들을 표시합니다|

위 파일들의 실행을 위해 추가 작성한 자료구조 및 알고리즘들은 다음과 같습니다.

|파일명|설명|
|----|----|
|Config.cpp|봇 프로그램의 기본 설정값들을 정의해놓았습니다|
|MapTools.cpp|게임 맵 관련 헬퍼 함수들을 구현해놓았습니다|
|UnitData.cpp|유닛들의 상태를 관리하기 위한 자료구조를 정의해놓았습니다|
|WorkerData.cpp|일꾼 유닛들의 상태를 관리하기 위한 자료구조를 정의해놓았습니다|
|BuildOrderQueue.cpp|빌드 큐 및 빌드 큐 아이템을 정의해놓았습니다|
|MetaType.cpp|빌드 큐 아이템의 타입을 정의해놓았습니다|
|ConstructionTask.cpp|건물 건설 큐 아이템을 정의해놓았습니다|
|ConstructionPlaceFinder.cpp|건물을 건설할 장소를 찾는 함수들을 구현해놓았습니다|
|CommandUtil.cpp|유닛에 대해 명령을 간편하게 내릴 수 있도록 함수들을 구현해놓았습니다|

## BasicBot Documentation

BasicBot 에 대한 상세한 내용은 BasicBot Documentation 웹사이트를 참고하세요 : [https://samsungsds-contest.github.io/2017Guide/](https://samsungsds-contest.github.io/2017Guide/)

