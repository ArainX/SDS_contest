# Contents

This is the **simplest** and **slickest** Markdown editor.  
Just write Markdown and see what it looks like as you type. And convert it to HTML in one click.

## Getting started

### How?

Just start typing in the left panel.

### Buttons you might want to use

- **Quick Reference**: that's a reminder of the most basic rules of Markdown
- **HTML | Preview**: *HTML* to see the markup generated from your Markdown text, *Preview* to see how it looks like

### Most useful shortcuts

- `CTRL + O` to open files
- `CTRL + T` to open a new tab
- `CTRL + S` to save the current file or tab

### Privacy

- No data is sent to any server – everything you type stays inside your application
- The editor automatically saves what you write locally for future use.  
  If using a public computer, close all tabs before leaving the editor

hello world

zz

# 하나

* 나카ㅁㅁㅁ

* 마마

- * 카카ㅁ
**몇몇 인공지능은 소스코드가 공개되어있는데요, 참고삼아 다운받아 살펴보셔도 좋을 것 같습니다.**

![스타크래프트 인공지능 화면](https://i.ytimg.com/vi/HjbZYHzcCjI/maxresdefault.jpg)

