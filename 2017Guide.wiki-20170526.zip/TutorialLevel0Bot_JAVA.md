# (입문 단계) 봇 프로그램 기본 구조 살펴보기

TutorialLevel0Bot 프로젝트를 통해, 봇 프로그램의 가장 기본적인 구조를 살펴보겠습니다.

## 개발 환경 설정

1. Eclipse 를 실행시킵니다

1. Package Explorer 에서 TutorialLevel0Bot 프로젝트를 선택합니다

1. 메뉴 -> Run -> Run Configurations... -> 왼쪽 트리에서 Java Application 밑에 TutorialLevel0Bot 을 선택합니다

1. 오른쪽 Arguments 탭 -> Working Directory : Others 에 C:\StarCraft 를 입력합니다


## 파일 목록

TutorialLevel0Bot 프로젝트를 구성하는 파일들은 다음과 같습니다.

|파일명|설명|
|----|----|
|Main.java|봇 프로그램의 시작 지점입니다. MyBotModule을 실행시킵니다|
|MyBotModule.java|스타크래프트 게임과 Connection 을 맺고, 스타크래프트 게임에서 발생하는 각 이벤트를 처리합니다. 스타크래프트 게임이 종료되면 봇 프로그램을 종료시킵니다|

## 스타크래프트 게임 이벤트 목록

스타크래프트 게임이 진행되면서 매순간 게임 이벤트가 발생하는데, 봇 프로그램은 이 이벤트들을 처리하는 프로그램 입니다.

다양한 이벤트의 종류들을 알고있으면 보다 효과적인 봇 프로그램을 작성할 수 있습니다.

**그러나, 일단은 onStart 과 onFrame 이벤트만 보고 넘어갑시다.**

|이벤트명|설명|
|----|----|
|**onStart**|**대결이 시작될 때 일회적으로 발생하는 이벤트**|
|onEnd|대결이 종료될 때 일회적으로 발생하는 이벤트|
|**onFrame**|**대결 진행 중 매 프레임마다 발생하는 이벤트. 1초에 50번 정도 실행될 것입니다**|
|onSendText|텍스트를 입력 후 엔터를 하여 다른 플레이어들에게 텍스트를 전달하려 할 때 발생하는 이벤트. 일반적으로, 디버깅용도로 텍스트 입력을 통해 봇 프로그램을 제어하는 코드가 들어가는 장소입니다|
|onReceiveText|다른 플레이어로부터 텍스트를 전달받았을 때 발생하는 이벤트|
|onPlayerLeft|다른 플레이어가 대결을 나갔을 때 발생하는 이벤트|
|onNukeDetect|핵미사일 발사가 감지되었을 때 발생하는 이벤트|
|onUnitCreate|유닛(건물/지상유닛/공중유닛)이 Create 될 때 발생하는 이벤트|
|onUnitDestroy|유닛(건물/지상유닛/공중유닛)이 Destroy 될 때 발생하는 이벤트|
|onUnitMorph|유닛(건물/지상유닛/공중유닛)이 Morph 될 때 발생하는 이벤트. Zerg 종족의 유닛은 건물 건설이나 지상유닛/공중유닛 생산에서 거의 대부분 Morph 형태로 진행됩니다.|
|onUnitShow|유닛(건물/지상유닛/공중유닛)이 Show 될 때 발생하는 이벤트. 아군 유닛이 Create 되었을 때 라든가, 적군 유닛이 Discover 되었을 때 발생합니다|
|onUnitHide|유닛(건물/지상유닛/공중유닛)이 Hide 될 때 발생하는 이벤트. 보이던 유닛이 Hide 될 때 발생합니다|
|onUnitComplete|유닛(건물/지상유닛/공중유닛)의 하던 일 (건물 건설, 업그레이드, 지상유닛 훈련 등)이 끝났을 때 발생하는 이벤트|
|onUnitDiscover|유닛(건물/지상유닛/공중유닛)이 Discover 될 때 발생하는 이벤트. 아군 유닛이 Create 되었을 때 라든가, 적군 유닛이 Discover 되었을 때 발생합니다|
|onUnitEvade|유닛(건물/지상유닛/공중유닛)이 Evade 될 때 발생하는 이벤트. 유닛이 Destroy 될 때 발생합니다|
|onUnitRenegade|유닛(건물/지상유닛/공중유닛)의 소속 플레이어가 바뀔 때 발생하는 이벤트. Gas Geyser에 어떤 플레이어가 Refinery 건물을 건설했을 때, Refinery 건물이 파괴되었을 때, Protoss 종족 Dark Archon 의 Mind Control 에 의해 소속 플레이어가 바뀔 때 발생합니다|
|onSaveGame|게임을 저장할 때 발생하는 이벤트|

## 1. Hello World 출력하기

스타크래프트 게임과 봇 프로그램을 실행시키는 방법은, [개발환경 설정 - 개발 IDE 설정 및 봇 프로그램 실행해보기 - 스타크래프트 게임과 봇 프로그램 실행시키기](./Environment3_JAVA.md) 부분을 참고바랍니다.

스타크래프트 게임 화면 및 명령 프롬프트 화면에 "Hello Starcraft" 텍스트를 출력하는 코드는 다음과 같이 MyBotModule 의 onFrame() 에 있습니다.

```java
(MyBotModule.java)

public void onFrame() {
	
	// 대결 시작한지 500 frame 이 되었을 때 1번만 표시
	if (Broodwar.getFrameCount() == 500) {

		// 명령 프롬프트에 표시
		System.out.println("Hello Starcraft command prompt");

		// 게임 화면에 표시
		Broodwar.printf("Hello Starcraft game screen");
	}

	
	if (Broodwar.isReplay()) {
		return;
	}
}
```

대결이 시작된 후 500 frame 시점이 되면, 명령 프롬프트 및 게임 화면에 텍스트가 출력됩니다.

## 2. 게임 이벤트 파악하기

TutorialLevel0Bot 에는 onFrame을 제외한 모든 게임 이벤트 발생 시 텍스트를 출력하고 있습니다. 예를 들어, onCreate 이벤트에 대해 텍스트를 출력하는 코드는 다음과 같습니다.

```java
(MyBotModule.java)

public void onUnitCreate(Unit unit){
	if (unit.getPlayer().isNeutral() == false) {
		Broodwar.printf(unit.getType() + " " + unit.getID() + " created at " + unit.getTilePosition().getX() + ", " + unit.getTilePosition().getY());
	}	
}
```

잠시 5분정도 스타크래프트 게임을 플레이해보면서, 언제 어떤 이벤트가 발생하는지 살펴보세요.


## 3. 게임 스피드 변경하기

봇 프로그램 개발 시 디버깅을 보다 원활하게 하기 위해서 게임 스피드를 조절해야할 경우가 있습니다. 스타크래프트 게임 스피드를 변경하는 코드는 다음과 같습니다. setLocalSpeed() 의 입력값을 조정해보세요.

```java
(MyBotModule.java)

public void onStart() {

    ...
    Broodwar.setLocalSpeed(20);
    ...
}
```

참고로, 알고리즘 경진대회에서의 게임 플레이 속도는 1 Frame 당 20 millisecond로 고정됩니다.

|게임 속도|1 Frame 당 소요시간|비고|
|----|----|----|
|Fastest|42 millisecond|일반적인 게임 플레이 속도|
|2배속|20 millisecond|알고리즘 경진대회에서의 게임 플레이 속도|
|4배속|10 millisecond|매우 빠른 속도|
|최대속도|0 millisecond|가능한 가장 빠른 속도|

