# (초급 단계) BWAPI 사용해보기

TutorialLevel1Bot 프로젝트를 통해, BWAPI 의 사용법을 익혀보겠습니다.

## 개발 범위 정의

1. 플레이어 정보 및 맵 정보를 Screen 화면에 표시

1. 현재 FrameCount 를 Screen 화면에 표시

1. 각 유닛 id 를 Map 화면에 표시

## 개발 환경 설정

1. Visual Studio Express 2013 를 실행시킵니다

1. 메뉴 -> File -> Open Project -> 개발폴더\C\BasicBot.sln 을 선택합니다

1. Solution Explorer -> TutorialLevel1Bot 우클릭 -> Set as StartUp Project 를 실행합니다

## 파일 목록

|파일명|설명|
|----|----|
|main.cpp|봇 프로그램의 시작 지점입니다. 스타크래프트 게임과 Connection 을 맺고, MyBotModule을 실행시키고, 스타크래프트 게임이 종료되면 봇 프로그램을 종료시킵니다|
|Common.h|각종 라이브러리 및 유틸리티를 include 시키는 헤더파일|
|MyBotModule.h|MyBotModule의 구조를 정의하는 헤더파일|
|MyBotModule.cpp|스타크래프트 게임에서 발생하는 각 이벤트를 처리합니다|

## 1. 플레이어 정보 및 맵 정보를 Screen 화면에 표시

스타크래프트 게임 Screen 화면에 플레이어 정보를 출력하는 코드는 다음과 같습니다.

BWAPI::Broodwar->self() 는 아군 플레이어 객체를 반환하는 함수이고, BWAPI::Broodwar->enemy() 는 적군 플레이어 객체를 반환하는 함수입니다.

```c
(MyBotModule.cpp)

void MyBotModule::onFrame(){
    ...
	// 플레이어 정보 표시
	BWAPI::Broodwar->drawTextScreen(5, 5, "My Player: %c%s (%s)", 
		BWAPI::Broodwar->self()->getTextColor(), 
		BWAPI::Broodwar->self()->getName().c_str(), 
		BWAPI::Broodwar->self()->getRace().c_str());

	BWAPI::Broodwar->drawTextScreen(5, 15, "Enemy Player: %c%s (%s)",
		BWAPI::Broodwar->enemy()->getTextColor(), 
		BWAPI::Broodwar->enemy()->getName().c_str(), 
		BWAPI::Broodwar->enemy()->getRace().c_str());
    ...
}
```

스타크래프트 게임을 실행시켜서, 아군 및 적군 플레이어의 이름 및 종족 정보가 제대로 표시되는지 살펴봅시다.

## 2. 현재 FrameCount 를 Screen 화면에 표시

스타크래프트 게임 Screen 화면에 현재 FrameCount 를 출력하는 코드는 다음과 같습니다.

```c
(MyBotModule.cpp)

void MyBotModule::onFrame(){
    ...
	// 현재 FrameCount 표시
	BWAPI::Broodwar->drawTextScreen(300, 100, "FrameCount: %d", 
		BWAPI::Broodwar->getFrameCount());
	
	...
}
```

## 3. 각 유닛 id 를 Map 화면에 표시

스타크래프트 게임 Map 화면 상의 모든 유닛들에 대해 id를 출력하는 코드는 다음과 같습니다.

아군 / 적군 플레이어의 건물 / 지상유닛 / 공중유닛 뿐만 아니라 Mineral, Gas Geyser 등에 대해서도 id 가 부여됨을 알 수 있습니다.

또한 id 가 출력되는 위치를 살펴보면 유닛 그래픽의 중앙부에 id 가 출력되는데, 이를 통해 unit->getPosition() 의 결과는 유닛 그래픽의 중앙부 임을 알 수 있습니다.

```c
(MyBotModule.cpp)

void MyBotModule::onFrame(){
    ...
	for (auto & unit : BWAPI::Broodwar->getAllUnits()) {
		BWAPI::Broodwar->drawTextMap(unit->getPosition().x, unit->getPosition().y, "%d", unit->getID());
	}
	...
}

```

