# C++ 개발환경 설정 및 봇 프로그램 실행해보기

## SDK 및 IDE 설치하기

1. 2017 알고리즘 경진대회 웹사이트에서 Visual Studio Express 2013 for Windows Desktop with Update 4 설치파일을 다운받아 실행합니다

## BasicBot 설치하기

1. 2017 알고리즘 경진대회 웹사이트에서 BasicBot.zip 을 다운받아 개발폴더 (ex: C:\Algorithm2017\BasicBot) 에 압축을 해제합니다

## 스타크래프트 게임과 봇 프로그램 실행시키기

1. 봇 프로그램을 실행하기 전에 먼저 chaoslauncher 를 사용하여 스타크래프트를 실행시켜야 합니다. chaoslauncher 를 실행시킨 후 Start 버튼을 클릭하여 스타크래프트를 실행시킵니다

1. Visual Studio Express 2013 를 실행시킵니다

1. 메뉴 -> File -> Open Project -> 개발폴더\C\BasicBot.sln 을 선택합니다

1. Solution Explorer -> TutorialLevel0Bot 우클릭 -> Set as StartUp Project 를 실행합니다

1. 메뉴 -> Debug -> Start without Debugging 을 실행합니다. 명령 프롬프트에 봇 프로그램이 실행될 것입니다

1. 스타크래프트 -> Single Player 클릭 (단축키 S) -> Expansion 클릭 (단축키 E) - New ID 생성 및 OK 클릭 -> Play Custom 클릭 (단축키 U) -> 게임 맵 선택 (ex: NeoLostTemple2.0.scm) -> Game Type 선택 (ex: Free For All) -> 플레이어로 Computer 가 1개만 남도록 변경 -> OK 클릭 -> 대결이 시작됩니다

1. 명령 프롬프트 화면 및 게임 화면을 살펴보세요. 봇 프로그램의 구조에 대해서는 Level0Bot 구조 살펴보기 페이지에서 설명하겠습니다.

## 봇 프로그램 디버깅 방법

1. 명령 프롬프트 화면을 클릭한 후 Pause (Break) 키를 누르면, 명령 프롬프트 화면 출력이 일어날 때 게임도 정지하게 됩니다

1. Visual Studio 의 Debug Mode 를 사용하는 방법은 [https://github.com/davechurchill/ualbertabot/wiki/Installation-Instructions](https://github.com/davechurchill/ualbertabot/wiki/Installation-Instructions) 의 How to Debug 를 참고하여 할 수 있으나, 게임 속도가 현저히 느려지는 문제가 있어서 권장하지는 않습니다.