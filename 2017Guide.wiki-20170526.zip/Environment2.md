# BWAPI 라이브러리 및 추가 파일 설치

## BWAPI 라이브러리 설치

1. 2017 알고리즘 경진대회 웹사이트에서 BWAPI-4.1.2_Setup.exe 파일을 다운받아 실행합니다

1. 설치 대상폴더 경로를 다음과 같이 합니다

    **C:\BWAPI412**

## 추가 파일 설치

1. 2017 알고리즘 경진대회 웹사이트에서 Algorithm2017.zip 파일을 다운받아 임의 폴더에 압축을 해제합니다

1. 압축을 해제한 폴더에서 install.bat 파일을 실행합니다. install.bat 파일은 다음과 같은 일을 수행합니다

    * 다음 dll 파일들을 C:\Windows 에 복사해넣습니다

      gmp-vc90-mt.dll, gmp-vc90-mt-gd.dll, libgmp-10.dll, libmpfr-4.dll, mpfr-vc90-mt.dll, mpfr-vc90-mt-gd.dll

    * 다음 dll 파일들을 C:\StarCraft 에 복사해넣습니다

      libgmp-10.dll, libmpfr-4.dll, bwapi_bridge2_5.dll

    * 다음 개발 라이브러리 파일들을 C:\StarCraft\bwlibrary 에 복사해넣습니다

      BWTA 2.2 (맵 분석 라이브러리)
      BWMirror 2.5 (JAVA와 BWAPI간 연결 라이브러리)

    * 대회 맵 파일들을 C:\StarCraft\Maps 에 복사해넣습니다

    * BWAPI 설정 파일들 및 BWTA 맵 분석 결과 파일들을 C:\StarCraft\bwapi-data 에 복사해넣습니다

    * 다음 샘플 봇 프로그램들을 C:\StarCraft\bwapi-data\AI 에 복사해넣습니다

      ZZZKBot (저그 봇), Steamhammer (저그 봇), Overkill (저그 봇), KillerBot (저그 봇), Iron (테란 봇), UAlbertaBot (랜덤 종족 봇)

1. 방화벽 설정이나 Proxy 설정은 각자 상황에 맞게 하시길 바랍니다

## chaoslauncher 를 사용하여 스타크래프트 실행시키기

1. C:\BWAPI412\Chaoslauncher\Chaoslauncher - MultiInstance.exe 파일을 실행합니다 (파일 우클릭 - 관리자 권한으로 실행 을 클릭하여 실행시키면 더 좋습니다)

1. Settings 탭의 Launcher 그룹에 있는 모든 체크박스를 체크해제한 후 OK 버튼을 클릭합니다)

1. Plugins 탭의 W-MODE 1.02 항목 체크박스를 체크합니다

1. Plugins 탭의 BWAPI 4.1.2 Injector [RELEASE] 항목 체크박스를 체크합니다

1. 하단의 Start 버튼을 클릭하여 스타크래프트를 실행시킵니다