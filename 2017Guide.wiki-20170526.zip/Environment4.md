# 팀 협업환경 설정

## 팀 협업공간

* 깃든샘(GitnSam), 깃랩(GitLab) 등 자율적으로 설정하시기 바랍니다

## 팀원간 대전

* 팀원간 대전은 스타크래프트 - Multiplayer - Local Area Network (UDP) 로 하면 됩니다

* Battle.net 은 사내 방화벽 정책상 작동하지 않습니다

