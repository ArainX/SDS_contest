var searchData=
[
  ['logfilename',['LogFilename',['../class_config.html#a891c129a3ff7d1e2e21c9233ef41f018',1,'Config']]],
  ['logtoconsole',['LogToConsole',['../class_config.html#aa844767b15de44cca56e21239a85012d',1,'Config']]]
];
