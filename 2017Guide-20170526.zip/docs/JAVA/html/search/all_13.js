var searchData=
[
  ['validateworkersandbuildings',['validateWorkersAndBuildings',['../class_construction_manager.html#a9850ff1737298566c68990b72f28f6d7',1,'ConstructionManager']]],
  ['validunits',['validUnits',['../class_information_manager.html#ad88b609ebcc67f313be016f2488b39bf',1,'InformationManager']]]
];
