var searchData=
[
  ['validateworkersandbuildings',['validateWorkersAndBuildings',['../class_construction_manager.html#a9850ff1737298566c68990b72f28f6d7',1,'ConstructionManager']]]
];
