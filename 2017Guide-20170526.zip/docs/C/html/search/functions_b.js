var searchData=
[
  ['normal',['normal',['../struct_my_bot_1_1double2.html#aaea51a0e39ec2b90687248fd077e0175',1,'MyBot::double2']]],
  ['normalise',['normalise',['../struct_my_bot_1_1double2.html#a86f461976610f8ecc2473834fd0e7008',1,'MyBot::double2']]]
];
