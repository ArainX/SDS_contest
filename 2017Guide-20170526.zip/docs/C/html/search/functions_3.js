var searchData=
[
  ['depothasenoughmineralworkers',['depotHasEnoughMineralWorkers',['../class_my_bot_1_1_worker_data.html#ac72f222106041007f47a56b75cbe0e66',1,'MyBot::WorkerData']]],
  ['distancemap',['DistanceMap',['../class_my_bot_1_1_distance_map.html#a014e02787b96b776a17e3594de7d4e1d',1,'MyBot::DistanceMap']]],
  ['dot',['dot',['../struct_my_bot_1_1double2.html#a1fd211a45774fc74cf976b3e643fb639',1,'MyBot::double2']]],
  ['double2',['double2',['../struct_my_bot_1_1double2.html#abad10b67c3f73d3020162f9f5056a5fc',1,'MyBot::double2::double2()'],['../struct_my_bot_1_1double2.html#ab5003346647241e9f88941735278a371',1,'MyBot::double2::double2(double x, double y)'],['../struct_my_bot_1_1double2.html#ad8ddeb3aa3d33b7875e93aa9a71716df',1,'MyBot::double2::double2(const BWAPI::Position &amp;p)']]]
];
