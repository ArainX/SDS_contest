var searchData=
[
  ['gasneeded',['gasNeeded',['../class_my_bot_1_1_worker_move_data.html#adfa7037c6b652d95291c5d852ac2020a',1,'MyBot::WorkerMoveData']]]
];
