var searchData=
[
  ['unitandunitinfomap',['UnitAndUnitInfoMap',['../namespace_my_bot.html#aad17dfb7cf6287af0f9c93b75c47ffd6',1,'MyBot']]]
];
