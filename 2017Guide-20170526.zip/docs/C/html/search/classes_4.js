var searchData=
[
  ['informationmanager',['InformationManager',['../class_my_bot_1_1_information_manager.html',1,'MyBot']]]
];
