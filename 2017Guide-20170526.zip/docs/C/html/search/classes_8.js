var searchData=
[
  ['unitdata',['UnitData',['../class_my_bot_1_1_unit_data.html',1,'MyBot']]],
  ['unitinfo',['UnitInfo',['../struct_my_bot_1_1_unit_info.html',1,'MyBot']]],
  ['uxmanager',['UXManager',['../class_my_bot_1_1_u_x_manager.html',1,'MyBot']]]
];
