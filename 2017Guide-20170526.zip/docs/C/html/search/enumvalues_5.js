var searchData=
[
  ['gas',['Gas',['../class_my_bot_1_1_worker_data.html#ae1e613170be6b14b789a2a6ecfbdff76acb3604129dec882916298407d2f16fcf',1,'MyBot::WorkerData']]]
];
