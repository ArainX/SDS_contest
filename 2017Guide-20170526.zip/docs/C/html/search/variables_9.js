var searchData=
[
  ['oppunits',['oppUnits',['../class_my_bot_1_1_grid_cell.html#a1c672ef1b90dafcc16383229611fb685',1,'MyBot::GridCell']]],
  ['ourunits',['ourUnits',['../class_my_bot_1_1_grid_cell.html#aa6ff0a34d42f4f5dbe5963a36eefeb0d',1,'MyBot::GridCell']]]
];
