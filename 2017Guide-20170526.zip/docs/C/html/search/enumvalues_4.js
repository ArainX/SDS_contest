var searchData=
[
  ['firstchokepoint',['FirstChokePoint',['../struct_my_bot_1_1_build_order_item.html#a0c05c4436d22ba5345efeb87e170dd72ac875b6327429b6887c61fb55ecbaed6b',1,'MyBot::BuildOrderItem']]],
  ['firstexpansionlocation',['FirstExpansionLocation',['../struct_my_bot_1_1_build_order_item.html#a0c05c4436d22ba5345efeb87e170dd72a65d22ba10176d638621d883c523e7fd5',1,'MyBot::BuildOrderItem']]]
];
