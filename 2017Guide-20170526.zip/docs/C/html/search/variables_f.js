var searchData=
[
  ['width',['width',['../struct_my_bot_1_1_rect.html#a1bcaafa8b61a549d2092c8fc3d569256',1,'MyBot::Rect']]],
  ['workersperrefinery',['WorkersPerRefinery',['../namespace_config_1_1_macro.html#aaab73aa0be50cacea83f499fe0725b8f',1,'Config::Macro']]],
  ['writedirectory',['WriteDirectory',['../namespace_config_1_1_files.html#aa0d5e58ab821a607c13a105b1188b46d',1,'Config::Files']]]
];
