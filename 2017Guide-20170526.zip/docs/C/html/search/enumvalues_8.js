var searchData=
[
  ['newmethod',['NewMethod',['../namespace_my_bot_1_1_construction_place_search_method.html#a491d55c5662fc0e38acbf263dcef5fb0abcdbd7a5ba6b792c4ac3f70fc5689130',1,'MyBot::ConstructionPlaceSearchMethod']]],
  ['noscout',['NoScout',['../namespace_my_bot_1_1_scout_status.html#a1171b452207555a9aaebec7a5e0d8950a334de49779cdaf3a66d37aa82e9d122a',1,'MyBot::ScoutStatus']]]
];
