var searchData=
[
  ['timelastopponentseen',['timeLastOpponentSeen',['../class_my_bot_1_1_grid_cell.html#a44156dbd93596100bd8a611ae6a5cc28',1,'MyBot::GridCell']]],
  ['timelastvisited',['timeLastVisited',['../class_my_bot_1_1_grid_cell.html#af210f8b5bb1c43f627534239a3275d19',1,'MyBot::GridCell']]],
  ['type',['type',['../class_my_bot_1_1_construction_task.html#a65a9416b64358d3c1dfc45ba76333f66',1,'MyBot::ConstructionTask::type()'],['../struct_my_bot_1_1_unit_info.html#a255d3988c2cfd21e0d27ebb9a13eacbd',1,'MyBot::UnitInfo::type()']]]
];
