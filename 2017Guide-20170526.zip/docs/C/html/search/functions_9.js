var searchData=
[
  ['len',['len',['../struct_my_bot_1_1double2.html#a447f0fa106cafbff2c1ced0403a10e89',1,'MyBot::double2']]],
  ['lensq',['lenSq',['../struct_my_bot_1_1double2.html#a29aca44650bb17ab5365327e05765a06',1,'MyBot::double2']]]
];
