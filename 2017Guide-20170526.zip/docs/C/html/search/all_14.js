var searchData=
[
  ['x',['x',['../struct_my_bot_1_1_rect.html#a88df815ad20497ca1765784978e174d1',1,'MyBot::Rect::x()'],['../struct_my_bot_1_1double2.html#a84b388a8182044fd883dad0855c4cb4e',1,'MyBot::double2::x()']]]
];
