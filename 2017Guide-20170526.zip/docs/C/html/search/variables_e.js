var searchData=
[
  ['underconstruction',['underConstruction',['../class_my_bot_1_1_construction_task.html#a12faffafb21f3fda1d65839783e3021d',1,'MyBot::ConstructionTask']]],
  ['unit',['unit',['../struct_my_bot_1_1_unit_info.html#a733b85ab6aae8b25bf27c8bcd1586c51',1,'MyBot::UnitInfo']]],
  ['unitid',['unitID',['../struct_my_bot_1_1_unit_info.html#a293e707a67bb9a45c3916554c397485e',1,'MyBot::UnitInfo']]]
];
