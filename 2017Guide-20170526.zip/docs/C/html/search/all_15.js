var searchData=
[
  ['y',['y',['../struct_my_bot_1_1_rect.html#ac84e5761d2f958efe7cba3db2571c575',1,'MyBot::Rect::y()'],['../struct_my_bot_1_1double2.html#a76803bb33387aa1afc92f056485920bf',1,'MyBot::double2::y()']]]
];
