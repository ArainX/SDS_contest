var searchData=
[
  ['seedpositionstrategy',['SeedPositionStrategy',['../struct_my_bot_1_1_build_order_item.html#a0c05c4436d22ba5345efeb87e170dd72',1,'MyBot::BuildOrderItem']]]
];
