var searchData=
[
  ['distancemap',['DistanceMap',['../class_my_bot_1_1_distance_map.html',1,'MyBot']]],
  ['double2',['double2',['../struct_my_bot_1_1double2.html',1,'MyBot']]]
];
