var searchData=
[
  ['scoutmanager',['ScoutManager',['../class_my_bot_1_1_scout_manager.html',1,'MyBot']]],
  ['strategymanager',['StrategyManager',['../class_my_bot_1_1_strategy_manager.html',1,'MyBot']]]
];
