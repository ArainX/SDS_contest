var searchData=
[
  ['player',['player',['../struct_my_bot_1_1_unit_info.html#a07666aba662e94a42877f934ec5654f6',1,'MyBot::UnitInfo']]],
  ['position',['position',['../class_my_bot_1_1_worker_move_data.html#aad72460b6a55e503eb9a7c2bd4f0f473',1,'MyBot::WorkerMoveData']]],
  ['priority',['priority',['../struct_my_bot_1_1_build_order_item.html#a7676395e514c370640b99c7ee9a205d4',1,'MyBot::BuildOrderItem']]],
  ['producerid',['producerID',['../struct_my_bot_1_1_build_order_item.html#aeb0b3f10ce185cecea926b0d2f277420',1,'MyBot::BuildOrderItem']]]
];
