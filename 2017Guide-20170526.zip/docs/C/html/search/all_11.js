var searchData=
[
  ['tech',['Tech',['../namespace_my_bot_1_1_meta_types.html#a59b94a6aece9394328865a2cac0fed79a2d1c4cbe0a607478c4a3f97dcd63f275',1,'MyBot::MetaTypes']]],
  ['timelastopponentseen',['timeLastOpponentSeen',['../class_my_bot_1_1_grid_cell.html#a44156dbd93596100bd8a611ae6a5cc28',1,'MyBot::GridCell']]],
  ['timelastvisited',['timeLastVisited',['../class_my_bot_1_1_grid_cell.html#af210f8b5bb1c43f627534239a3275d19',1,'MyBot::GridCell']]],
  ['type',['type',['../class_my_bot_1_1_construction_task.html#a65a9416b64358d3c1dfc45ba76333f66',1,'MyBot::ConstructionTask::type()'],['../struct_my_bot_1_1_unit_info.html#a255d3988c2cfd21e0d27ebb9a13eacbd',1,'MyBot::UnitInfo::type()'],['../class_my_bot_1_1_meta_type.html#a874759a354d65687397270370ae00417',1,'MyBot::MetaType::type()']]]
];
