var searchData=
[
  ['build',['Build',['../class_my_bot_1_1_worker_data.html#ae1e613170be6b14b789a2a6ecfbdff76a9d6d0eb8359d321b2ab5be62224c328b',1,'MyBot::WorkerData']]]
];
