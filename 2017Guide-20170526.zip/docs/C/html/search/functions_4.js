var searchData=
[
  ['existsenemybuildinginregion',['existsEnemyBuildingInRegion',['../class_my_bot_1_1_information_manager.html#a96f812f9a672b25e473102f70b091f85',1,'MyBot::InformationManager']]],
  ['existsmybuildinginregion',['existsMyBuildingInRegion',['../class_my_bot_1_1_information_manager.html#ac9d30fbc4393f52a3098273508522c46',1,'MyBot::InformationManager']]]
];
