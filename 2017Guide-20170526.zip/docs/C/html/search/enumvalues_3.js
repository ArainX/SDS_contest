var searchData=
[
  ['default',['Default',['../class_my_bot_1_1_worker_data.html#ae1e613170be6b14b789a2a6ecfbdff76a1c3574b878121eeb9962184d53532e2c',1,'MyBot::WorkerData::Default()'],['../namespace_my_bot_1_1_meta_types.html#a59b94a6aece9394328865a2cac0fed79af5f5e4fced186babf15e88632f471f02',1,'MyBot::MetaTypes::Default()']]]
];
