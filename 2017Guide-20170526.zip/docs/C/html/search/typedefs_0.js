var searchData=
[
  ['metapair',['MetaPair',['../namespace_my_bot.html#ac6bda5df123cfb256719b777338bf4c0',1,'MyBot']]],
  ['metapairvector',['MetaPairVector',['../namespace_my_bot.html#adba15da4e5ff484e45c5280bf2bef9af',1,'MyBot']]]
];
