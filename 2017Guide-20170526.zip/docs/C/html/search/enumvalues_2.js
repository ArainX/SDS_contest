var searchData=
[
  ['combat',['Combat',['../class_my_bot_1_1_worker_data.html#ae1e613170be6b14b789a2a6ecfbdff76af48c1132a7f848b82110564932e0e93a',1,'MyBot::WorkerData']]]
];
